"""
Brendan Ritter 5/3/13
A basic node class. Defines the structure of a neural network.
A node also doubles as a binary threshold neuron.
"""

class Node(object):
	def __init__(self,name,threshold_val=0):
		self.name=name
		self.parents=dict()
		self.children=list()
		self.threshold_val=threshold_val
		self.output=None
	def __str__(self):
		return "Node "+self.name+" with threshold "+str(self.threshold_val)
	"""
	Returns 1 if above threshold. Returns 0 if not.
	Some NNs define the output to be -1 and 1.
	"""
	def threshold_func(self,wsum):
		if wsum>=self.threshold_val:
			return 1
		else:
			return 0
	"""
	The way the network is defined, the child remembers the weight.
	"""
	def add_parent(self,node,weight):
		self.parents[node]=weight
	def add_child(self,node):
		self.children.append(node)
	"""
	The node looks at all of its parents and calculates the weighted sum of all the parent's outputs
	"""
	def calculate(self):
		wsum=0
		for input_node, weight in self.parents.items():
			wsum+=weight*input_node.output
		return self.threshold_func(wsum)
	def calc_and_set(self):
		self.output=self.calculate()


