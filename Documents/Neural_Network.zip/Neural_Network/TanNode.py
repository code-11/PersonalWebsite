import math
class TanNode(Node):
	def threshold_func(self,wsum):
		return math.tanh(wsum)
	def derivative_func(self, x):
		return 1-(math.tanh(x)*math.tanh(x))