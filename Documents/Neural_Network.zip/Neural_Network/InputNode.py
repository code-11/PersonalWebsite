from Node import Node
"""
Brendan Ritter 5/3/13
Input nodes don't need any functions or parents, just children 
and the ability for calc_and_set to be called on them without it actually doing anything.
"""
class InputNode(Node):
	def __init__(self,name,threshold_val=None):
		Node.__init__(self,name,threshold_val)
		self.name=name
		self.children=list()
		self.output=None
	def __str__(self):
		return "Input Node "+self.name
	def add_child(self,node):
		self.children.append(node)
	def calc_and_set(self):
		pass