from Network import *
"""
Brendan Ritter 5/3/13
A class for the teaching of neural networks. 
Currently only the back propagation algorithm is implemented 
"""
class Teacher():
	def __init__(self,network):
		self.student=network
		self.error=None

	"""
	Takes a list of input and a list of output.
	Runs the other functions in network and teacher required for back propagation teaching.
	Runs the teaching algorithm only once.

	question-A list of input_nodes
	answer-Currently a list of one output
	"""
	def teach_once(self,question,answer):
		#For now, only one output neural networks are supported
		student_answer=self.student.calculate(question)[0]
		self.error=(answer-student_answer)#*student_answer*(1-student_answer)
		#print "NN says "+str(student_answer)+" answer is "+str(answer)+" error is "+str(self.error)
		self.error_calc()
		self.adjust_weights(1)

	"""
	Takes a list of input and a list of output.
	Runs teach once a given number of times.
	"""
	def teach_n(self,question,answer,n):
		for i in range(n):
			self.teach_once(question,answer)

	"""
	Takes a tuple/list of question, answer tuples and rotates through the tuple/list.
	This function rotates through the list so that the neural network doesn't forget 
	one question answer pair when it is learning others.

	NOTE If the n input is 4 for instance, and there are 2 tuples in the syllabus tuple, 
	this function will run teach_once a total of 8 times.    

	syllabus-A tuple/list of question, answer tuples
	n-The number of time it should teach based on that syllabus.

	"""
	def rotating_lesson_n(self,syllabus,n):
		for i in range(len(syllabus)*n):
			a_and_q=syllabus[i%len(syllabus)]
			self.teach_once(a_and_q[0],a_and_q[1])
			if i%len(syllabus)==0:
				#print " "
				pass
	"""
	Preforms the error calculations for every node except for inputs 
	since they have no error.
	The error in a back propagation algorithm, surprisingly enough propagates
	backward from the output to the input nodes. 

	"""
	def error_calc(self):
		to_expand=list(self.student.output_nodes)
		while len(to_expand)!=0:
			node=to_expand.pop(0)
			if node.children==[]:
				#For now, only one output neural networks are supported
				node.local_error=self.error
				#print "setting error of "+node.name+" to system error"
			else:
				node.error_and_set()
			for node_to_expand in node.parents.keys():
				if node_to_expand not in to_expand:
					if node_to_expand not in self.student.input_nodes:
						to_expand.append(node_to_expand)

	"""
	This is most important part of the back propagation algorithm
	This recursive method moves foward again through the network and uses information from both the parent and the child
	It calculates, using the backpropagated error on each node, the change in weight required to acheive the correct output.
	This method is called gradient descent and has many strengths and weaknesses.

	NOTES 
	The algorithm always converges, but not always on global minima (will not always learn the right thing)
	Implementation of "Momentum" in this process would help.

	tau-A super magical number that controls the learning 'speed'. 
	No one will share their secrets of its usual values so I had to use trial and error.
	Turns out that 1 works well for my purposes, which is strange since 1 makes tau not matter...
	"""
	def adjust_weights(self,tau):
		to_expand=list(self.student.input_nodes)
		while len(to_expand)!=0:
			to_change=dict()
			node=to_expand.pop(0)
			if node.parents!={}:
				wsum=0
				for input_node, weight in node.parents.items():
					wsum+=weight*input_node.output
				wsum+=node.threshold_val
				for node_to_check, weight in node.parents.items():
					#new_value=node.parents[node_to_check]+tau*node.local_error*node.derivative_func(wsum)*node_to_check.output
					new_value=node.parents[node_to_check]+tau*node.local_error*node_to_check.output*node.derivative_func(wsum)
					to_change[node_to_check]=new_value
					#node.parents[node_to_check]=new_value
					#print "weight from "+node_to_check.name+" to "+node.name+" was "+str(node.parents[node_to_check])+" is now "+str(new_value)+" because "+str(node_to_check.output)+", "+str(node.local_error)#+", "+str(node.derivative_func(wsum))
				node.threshold_val+=tau*node.local_error*node.derivative_func(wsum)
				node.parents=to_change
			for node_to_expand in node.children:
				if node_to_expand not in to_expand:
					to_expand.append(node_to_expand)



