"""
Brendan Ritter 5/3/13
"""
import os,sys
parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,parentdir) 
from SigNode import *
from InputNode import *
from Network import *
from Teacher import *

A=InputNode("A")
B=InputNode("B")

C=SigNode("C",1)
D=SigNode("D",1)
E=SigNode("E",1)
F=SigNode("F",1)

net=Network([A,B],[F])

#Weights don't matter since they're going to be randomized anyway.
net.connect(A,C,1)
net.connect(A,D,1)
net.connect(B,D,1)
net.connect(B,E,1)
net.connect(C,F,1)
net.connect(D,F,1)
net.connect(E,F,1)

net.randomize_weights([C,D,E,F])
teacher=Teacher(net)

syllabus=(([0,0],0),([0,1],1),([1,0],1),([1,1],0))
teacher.rotating_lesson_n(syllabus,1000)
comb1=net.calculate([0,0])[0]
comb2=net.calculate([1,0])[0]
comb3=net.calculate([0,1])[0]
comb4=net.calculate([1,1])[0]

print "0 xor 0 is ",comb1, " which is close to ", round(comb1)
print "1 xor 0 is ",comb2, " which is close to ", round(comb2)
print "0 xor 1 is ",comb3, " which is close to ", round(comb3)
print "1 xor 1 is ",comb4, " which is close to ", round(comb4)