"""
Brendan Ritter 5/3/13
"""
import os,sys
parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,parentdir) 
from SigNode import *
from Network import *
from InputNode import *

A=InputNode("A")
B=InputNode("B")

C=SigNode("C",-2.82)
D=SigNode("D",-2.74)
E=SigNode("E",-2.86)

net=Network([A,B],[E])

net.connect(A,C,4.83)
net.connect(A,D,-4.63)
net.connect(B,C,-4.83)
net.connect(B,D,4.6)
net.connect(C,E,5.73)
net.connect(D,E,5.83)

comb1=net.calculate([0,0])[0]
comb2=net.calculate([1,0])[0]
comb3=net.calculate([0,1])[0]
comb4=net.calculate([1,1])[0]

print "0 xor 0 is ",comb1, " which is close to ", round(comb1)
print "1 xor 0 is ",comb2, " which is close to ", round(comb2)
print "0 xor 1 is ",comb3, " which is close to ", round(comb3)
print "1 xor 1 is ",comb4, " which is close to ", round(comb4)