import os,sys
parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,parentdir) 
from Node import *
from Network import *
from InputNode import *

#input layer
A=InputNode("A")
B=InputNode("B")
#hidden layer
C=Node("C",.5)
D=Node("D",1.5)
E=Node("E",.5)
#output layer
F=Node("F",.5)

net=Network([A,B],[F])

net.connect(A,C,1)
net.connect(A,D,1)
net.connect(B,D,1)
net.connect(B,E,1)

net.connect(C,F,1)
net.connect(D,F,-2)
net.connect(E,F,1)

print "0 xor 0 is ",net.calculate([0,0])
print "1 xor 0 is ",net.calculate([0,1])
print "0 xor 1 is ",net.calculate([0,1])
print "1 xor 1 is ",net.calculate([1,1])