import os,sys
parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,parentdir) 
from Node import *
from Network import *
from InputNode import *

A=InputNode("A")
B=InputNode("B")
C=Node("C",.5)

net=Network([A,B],[C])
net.connect(A,C,.5)
net.connect(B,C,.5)

print "0 or 0 is ",net.calculate([0,0])
print "1 or 0 is ",net.calculate([0,1])
print "0 or 1 is ",net.calculate([0,1])
print "1 or 1 is ",net.calculate([1,1])