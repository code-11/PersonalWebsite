import math
from Node import Node

"""
Brendan Ritter 5/3/13
A subclass of node that uses a sigmoid activitation function.
It also includes extra functions for the training of neural nets.
"""
class SigNode(Node):
	def __init__(self,name,threshold_val=0):
		Node.__init__(self,name,threshold_val)
		self.local_error=None
	"""
	This function is overriden so that the threshold can be added to the weighted sum
	"""
	def calculate(self):
		wsum=0
		for input_node, weight in self.parents.items():
			wsum+=weight*input_node.output
		#In analog circuits, the threshold is actually a bias,
		#meaning it just gets added along with the rest of the parents.
		wsum+=self.threshold_val
		return self.threshold_func(wsum)
	"""
	Calculates the local error of the node.

	NOTE there should be a factor of derivative_func(wsum) included here
	However, by accident it is instead in Teacher (the back propagation algorithm itself)
	This needs to be fixed in order to provide additional implementation (hyperbolic tangent activation function)
	"""
	def calc_local_error(self):
		temp_error=0
		for child in self.children:
			#print "node "+self.name+" has "+str(len(self.children))+" children whose error was "+str(self.children[0].local_error)
			weight=child.parents[self]
			temp_error+=weight*child.local_error
			#print "adding error for "+self.name+" to be: "+str(weight*child.local_error)+" because "+str(child.local_error)+", "+str(weight)
		return temp_error
	def error_and_set(self):
		self.local_error=self.calc_local_error()
		#print "error for node "+self.name+" is "+str(self.local_error)
	def threshold_func(self,wsum):
		return 1.0/(1.0+math.exp(-1*wsum))
	def derivative_func(self, x):
		return self.threshold_func(x)*(1.0-self.threshold_func(x))