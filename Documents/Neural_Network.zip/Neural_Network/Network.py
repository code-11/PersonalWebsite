import random
"""
Brendan Ritter 5/3/13
"""
class Network(object):
	"""
	Creates a Network object given a list of input nodes 
	and a list of nodes to receive output from.
	Technically, output nodes can be any node, not just nodes without 
	children. This allows you to 'listen in' on any part of the network
	"""
	def __init__(self,input_nodes=list(),output_nodes=list()):
		self.input_nodes=input_nodes
		self.output_nodes=output_nodes
	"""
	Connects two nodes together. The connection is two way.
	However, the child also needs a weight associated with the parent.

	parent-The node that point to the child
	child-The node that gets pointed to by the parent
	"""
	def connect(self,parent, child, weight):
		parent.add_child(child)
		child.add_parent(parent, weight)
	"""
	Puts input into the correct input nodes. 
	NOTE A better way of doing this would use a dictionary from node to input.

	input_vars-A list of input values for the neural network
	"""
	def load_vals(self,input_vals):
		for i in range(len(input_vals)):
			self.input_nodes[i].output=input_vals[i]

	"""
	A helper function for calculate that takes care of the expansion of the nodes during foward calculation.
	It also gathers the output of the Output nodes.

	node-The current node in the recursive foward calculation
	to_expand-A list of nodes to expand, used as a stack.
	to_return-A list of output values. 
	"""
	def calc_recurse(self, node, to_expand,to_return):
		node.calc_and_set()
		if node in self.output_nodes:
			to_return.append(node.output)
		for node_to_expand in node.children:
			if node_to_expand not in to_expand:
				to_expand.append(node_to_expand)

	"""
	Preforms the foward calculation of the neural network given some amount of input.
	It recursively moves through the network and saves 
	all output from each node to itself, for latter retreival by the back propagation algorithm

	input_vals-A list of values to input to the input layer...input
	"""
	def calculate(self,input_vals):
		to_return=list()
		if len(input_vals)!=len(self.input_nodes):
			print "Error, ", len(input_vals), "inputs given for ",len(self.input_nodes)," input nodes"
		else:
			self.load_vals(input_vals)
			to_expand=list(self.input_nodes)
			while len(to_expand)>0:
				node=to_expand.pop(0)
				self.calc_recurse(node,to_expand, to_return)
		return to_return
	"""
	Randomizes all weights and thresholds for the given list of nodes.

	children-A list of nodes whose weights and thresholds should be randomized.
	"""
	def randomize_weights(self,children):
		for child in children:
			for input_node, weight in child.parents.items():
				child.parents[input_node]=round((random.random()-.5)*2,2)
			child.threshold_val=round((random.random()-.5)*2,2)
		#self.print_weights(children)

	"""
	A useful method for debugging. Simply displays the weights and thresholds for a given list of nodes.

	children-A list of nodes to print 
	"""
	def print_weights(self,children):
		for child in children:
			for input_node, weight in child.parents.items():
				print "weight from "+input_node.name+" to "+child.name+" is "+str(child.parents[input_node])
			print "bias/weight for "+child.name+" is "+str(child.threshold_val)



			

