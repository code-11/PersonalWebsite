Brendan Ritter 5/3/13
README

Contained within this folder is a basic set of functions for the creation of neural networks.

Also inluded is a class that contains a implementation of the back propagation algorithm for teaching NNs

Examples of the capabilities of these funcitons are located in the Example folder and include:

	Binary threshold networks for the major boolean operations including:
		and, or nand, and xor (multiple layers)

	.png files for the better visualization of the more complicated networks.

	An analog sigmoid neural network for XOR (Weights assigned by hand)

	An analog sigmoid neural network for XOR (Weights learned through back propagation)
		Although this example is intended for Xor, it can actually learn any of the other
		boolean operations also...yay!

There are some things that are missing/could be implemented (see TodoList.txt)

Examples need the functions to be in the folder above them. Don't move the examples without the code and vice versa

Try stuff out. It was working when I last used it. The coolest example in my opinion is the analog trained XOR NN.
If it is not working, I swear it was, and there is proof located in Examples/proof.png



All code contained within was written from scratch by Brendan Ritter. The picture can be found easily through google images.

