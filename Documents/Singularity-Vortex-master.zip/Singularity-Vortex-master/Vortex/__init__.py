from loadImage import *
# input: filepath
# input: red, green, blue
from applyTransform import * 
#array, transform, newSize=None
from flip import *
# inpus: filepath  and d where d==1 is vertical flip and d==2 is horizontal flip
from colorbalance import * 
#imagefilepath,channel,num

from greyscale import *

from edgeDetection import *

from Layers import *

from invert import *

from color import *