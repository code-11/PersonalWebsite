from loadImage import*
import scipy
import scipy.ndimage.interpolation
from PIL import Image
import numpy
import pdb

def flip(image, d):
	'''
		flips image based on direction d. image is [rarray, garray, array]
		
	'''
	bunny = image
	bunny= load_image(imageFilepath)

	red = bunny[0]
	green = bunny[1]
	blue = bunny[2]
	
	rM= numpy.matrix(red)
	gM= numpy.matrix(green)
	bM= numpy.matrix(blue)

	
	iM= numpy.zeros([red.shape[0], red.shape[1]])
	iM= numpy.matrix(iM)
	
	print iM
	for i in range (red.shape[0]):
		iM[i,(red.shape[1]-1-i)]= 1	
	
	bout=0
	if d == 1:
		#Filps Vertically
		bout= numpy.array([iM*rM, iM*gM, iM*bM])
	if d == 2:
		#Flips Horizontally
		bout= numpy.array([rM*iM, gM*iM, bM*iM])
	return bout
