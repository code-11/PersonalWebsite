import React from 'react';
import { render } from 'react-dom';
// import tasks from './reducers';
import TrackingApp from './components/TrackingApp';

render(
        <TrackingApp/>,
    document.getElementById('app')
);
