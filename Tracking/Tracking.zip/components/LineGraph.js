import React, { Component } from 'react';
import {Stage, Layer, Line, Circle} from 'react-konva';

export default class LineGraph extends Component { 
	constructor(props){
		super(props);
		const {data}=this.props;
	}

	trans(xMin,xMax,yMin,yMax,pt){
		const {data, width, height} = this.props;
		const xWidth=xMax;//-xMin;
		const xPos=(width/xWidth) * pt[0]

		const yHeight=yMax;//-yMin;
		const yPos=height-((height/yHeight) * pt[1])
		return [xPos,yPos];
	}

	renderSeries(){
		const {data} = this.props;

		const xMax=data.map(pt=>pt[0]).reduce((mx,el)=>Math.max(el,mx));
		const xMin=data.map(pt=>pt[0]).reduce((mx,el)=>Math.min(el,mx));
		const yMax=data.map(pt=>pt[1]).reduce((mx,el)=>Math.max(el,mx));
		const yMin=data.map(pt=>pt[1]).reduce((mx,el)=>Math.min(el,mx));

		const transformedPts=data.map((pt)=>{
			return this.trans(xMin,xMax,yMin,yMax,pt);
		});

		const combinedPoints= transformedPts.flat();
		return <Line
			points={combinedPoints}
			stroke={'black'}
		/>;
	}

	renderAxis(){
		const{width, height, axisThickness} = this.props;
		return <React.Fragment>
			<Line 
				points={[0,height-axisThickness,width,height-axisThickness]}
				stroke={"black"}
				strokeWidth={axisThickness}
			/>
			<Line 
				points={[axisThickness,height,axisThickness,0]}
				stroke={"black"}
				strokeWidth={axisThickness}
			/>
		</React.Fragment>
	}

	render(){
		const {width,height,points} = this.props;
	    return <Stage width={width} height={height}>
	      <Layer>
			{this.renderAxis()}
			{this.renderSeries()}
	      </Layer>
	    </Stage>
	}

}