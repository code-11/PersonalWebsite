export default class GDriveUtil {
	constructor(){
		super();
	}
}